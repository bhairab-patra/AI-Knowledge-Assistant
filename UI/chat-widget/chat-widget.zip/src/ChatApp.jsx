
import React, { useState, useRef, useEffect } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import ConfirmDialog from './component/ConfirmDialog';
import Tooltip from './component/Tooltip';
import './ChatApp.css';
import logger from './utils/logger';
import api, { getViewUrl } from './services/api';
import rehypeSanitize from 'rehype-sanitize';

export default function ChatApp({ chatSessionId }) {

  const TRUNCATE_TITLE = 30;
  const FEEDBACK_CONFIRM_MS = 2000;
  const MAX_FEEDBACK_CHARS = 500;
  const MIN_INPUT_LENGTH = 3;
  const TEXTAREA_MIN_HEIGHT = 75;
  const TEXTAREA_MAX_HEIGHT = 120;
  const CHAT_WINDOW_HEIGHT = 600;
  const CHAT_WINDOW_WIDTH = 400;
  const MINIMIZED_SIZE = 100;

  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState([
    { role: 'assistant', content: 'Hi! How can I help you today?' }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isStreaming, setIsStreaming] = useState(false);
  const [streamingMessage, setStreamingMessage] = useState('');
  const messagesEndRef = useRef(null);
  const inputRef = useRef(null);
  const abortControllerRef = useRef(null);
  const [sessionId, setSessionId] = useState(null);
  const [chatUrl, setChatUrl] = useState(null);
  const [feedbackMap, setFeedbackMap] = useState({});
  const [isThinking, setIsThinking] = useState(false);
  const [expandedFeedback, setExpandedFeedback] = useState(null);
  const [feedbackComment, setFeedbackComment] = useState('');
  const [charCount, setCharCount] = useState(0);
  const [expandedSources, setExpandedSources] = useState({});
  const [showCloseDialog, setShowCloseDialog] = useState(false);
  const [assistantTitle, setAssistantTitle] = useState('Ask AI Assistant');
  const [headerColor, setHeaderColor] = useState(''); //#D0F4EE
  const [primaryColor, setPrimaryColor] = useState(''); //#12C6A8
  const [fontFamily, setFontFamily] = useState("'Roboto', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif");
  const [sessionError, setSessionError] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isMinimized, setIsMinimized] = useState(false);
  const [currentSessionMessageCount, setCurrentSessionMessageCount] = useState(1);
  const [hasUserSentMessage, setHasUserSentMessage] = useState(false);
  const [showMinimize, setShowMinimize] = useState(true);

  const MAX_CHARS = 2000;

  const ERROR_TYPES = {
    SESSION_EXPIRED: { code: 'SESSION_EXPIRED', message: 'Session expired. Please close and try again.', recoverable: false },
    SESSION_NOT_FOUND: { code: 'SESSION_NOT_FOUND', message: 'Session not found. Please close and try again.', recoverable: false },
    AUTH_FAILED: { code: 'AUTH_FAILED', message: 'Authentication failed. Please close and try again.', recoverable: false },
    NETWORK_ERROR: { code: 'NETWORK_ERROR', message: 'Connection issue or Session expired. Please try again.', recoverable: true },
    SERVER_ERROR: { code: 'SERVER_ERROR', message: 'Something went wrong. Please try again.', recoverable: true },
    UNKNOWN: { code: 'UNKNOWN', message: 'Session not found. Please close and try again.', recoverable: false },
  };

  const classifyHttpError = (status) => {
    if (status === 401) return ERROR_TYPES.AUTH_FAILED;
    if (status === 403) return ERROR_TYPES.SESSION_EXPIRED;
    if (status === 404) return ERROR_TYPES.SESSION_NOT_FOUND;
    if (status >= 500) return ERROR_TYPES.SERVER_ERROR;
    return ERROR_TYPES.UNKNOWN;
  };



  // Auto-scroll to bottom
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, streamingMessage]); //streamingMessage

  // Focus input when chat opens
  useEffect(() => {
    if (isOpen && inputRef.current) {
      inputRef.current.focus();
    }
  }, [isOpen]);


  useEffect(() => {
    if (
      chatSessionId &&
      chatSessionId !== null &&
      chatSessionId !== 'null' &&
      typeof chatSessionId === 'string' &&
      chatSessionId.trim().length > 0
    ) {
      // Fetch session details from backend
      fetchSessionDetails(chatSessionId);

    } else {
      // console.log('Invalid session - not opening');
      logger.warn('Invalid session - not opening')
      setIsOpen(false);
    }
  }, [chatSessionId]);


  useEffect(() => {
    const htmlElement = document.documentElement;
    const bodyElement = document.body;

    if (isMinimized) {
      htmlElement.style.height = `${MINIMIZED_SIZE}px`;
      htmlElement.style.width = `${MINIMIZED_SIZE}px`;
      bodyElement.style.height = `${MINIMIZED_SIZE}px`;
      bodyElement.style.width = `${MINIMIZED_SIZE}px`;
      bodyElement.style.pointerEvents = 'auto';

      // Ask parent to change iframe dimensions
      if (window.parent !== window) {
        window.parent.postMessage({
          type: 'CHANGE_IFRAME_HEIGHT',
          height: MINIMIZED_SIZE,
          width: MINIMIZED_SIZE
        }, '*');
      }

    } else if (isOpen) {
      htmlElement.style.height = `${CHAT_WINDOW_HEIGHT}px`;
      htmlElement.style.width = `${CHAT_WINDOW_WIDTH}px`;
      bodyElement.style.height = `${CHAT_WINDOW_HEIGHT}px`;
      bodyElement.style.width = `${CHAT_WINDOW_WIDTH}px`;
      bodyElement.style.pointerEvents = 'auto';

      // Ask parent to change iframe dimensions
      if (window.parent !== window) {
        window.parent.postMessage({
          type: 'CHANGE_IFRAME_HEIGHT',
          height: CHAT_WINDOW_HEIGHT,
          width: CHAT_WINDOW_WIDTH
        }, '*');
      }
    }
  }, [isMinimized, isOpen]);


  useEffect(() => {
    const handleVisibilityChange = async () => {
      if (document.visibilityState === 'visible' && sessionId && isOpen) {
        try {
          const response = await fetch(`${API_BASE_URL}/api/v1/sessions/${sessionId}`, {
            method: 'GET',
            headers: { 'Content-Type': 'application/json' }
          });
          const data = await response.json();
          if (!response.ok || data.status !== 'active') {
            setSessionError('Session expired or invalid. Please close and try again.');
            setIsOpen(false);
          }
        } catch (error) {
          console.error('Session revalidation failed:', error);
        }
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    return () => document.removeEventListener('visibilitychange', handleVisibilityChange);
  }, [sessionId, isOpen]);


  const fetchSessionDetails = async (sessionId) => {
    setIsLoading(true);
    try {
      const response = await api.getSession(sessionId);
      logger.info('api.getSession(sessionId)')
      const data = await response.json();
      if (response.ok && data.status === "active") {
        setSessionError(null);
        setSessionId(sessionId);

        let restoredMessages;

        if (data.conversationHistory && data.conversationHistory.length > 0) {
          restoredMessages = [
            { role: 'assistant', content: 'Hi! How can I help you today?' },
            ...data.conversationHistory
          ];

        } else {
          restoredMessages = [{ role: 'assistant', content: 'Hi! How can I help you today?' }];
        }

        // Set messages
        setMessages(restoredMessages);
        setCurrentSessionMessageCount(restoredMessages.length);

        // Restore feedback state if exists
        if (data.latestFeedback) {
          const { messageIndex, rating } = data.latestFeedback;
          setFeedbackMap({
            [messageIndex]: {
              type: rating === 'positive' ? 'up' : 'down',
              disabled: true,
              showConfirm: false
            }
          });
        }

        // Track if this is a restored session or new session
        setHasUserSentMessage(false);

        if (data.customization) {
          if (data.customization.assistantTitle) {
            setAssistantTitle(data.customization.assistantTitle);
          }
          if (data.customization.headerColor) {
            setHeaderColor(data.customization.headerColor);
          }
          if (data.customization.primaryColor) {
            setPrimaryColor(data.customization.primaryColor);
          }
          if (data.customization.fontFamily) {
            const customFont = data.customization.fontFamily;

            // Add fallback fonts
            const fontWithFallbacks = customFont === 'system-ui'
              ? 'system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif'
              : `'${customFont}', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif`;

            setFontFamily(fontWithFallbacks);
          }
          if (data.customization.showMinimize !== undefined) {
            setShowMinimize(data.customization.showMinimize);
          }
        }

        setIsOpen(true);
        setIsLoading(false);
        // console.log('Chat opened successfully');
        logger.info('Chat opened successfully')
      } else {
        const error = classifyHttpError(response.status);
        console.error(`Session error [${error.code}]:`, response.status);
        setSessionError(error);
        setIsLoading(false);
        setIsOpen(false);
      }

    } catch (error) {
      console.error(`Session fetch error [NETWORK_ERROR]:`, error.message);
      setSessionError(ERROR_TYPES.NETWORK_ERROR);
      setIsLoading(false);
      setIsOpen(false);
    }
  };

  // Handle close
  const handleCloseError = () => {
    setSessionError(null);
    setIsOpen(false);
    // Notify parent
    if (window.parent !== window) {
      window.parent.postMessage({ type: 'CHAT_CLOSED' }, '*');
    }
  };

  // Update sendMessageWithStreaming
  const sendMessageWithStreaming = async () => {
    if (!inputValue.trim() || isStreaming) return;

    if (!sessionId) {
      setSessionError('No active session. Please close and try again.');
      setIsOpen(false);
      return;
    }

    const userMessage = inputValue.trim();

    // Mark that user has sent a message in this widget session
    if (!hasUserSentMessage) {
      setHasUserSentMessage(true);
    }

    setInputValue('');
    setCharCount(0);
    if (inputRef.current) {
      inputRef.current.style.height = 'auto';
    }

    const newMessages = [...messages, { role: 'user', content: userMessage }];
    setMessages(newMessages);
    setIsStreaming(true);
    setIsThinking(true);
    setStreamingMessage('');

    abortControllerRef.current = new AbortController();

    try {
      const response = await api.sendQuery(userMessage, sessionId, abortControllerRef.current.signal);
      if (!response.ok) {
        const error = classifyHttpError(response.status);
        if (!error.recoverable) {
          setIsThinking(false);
          setIsStreaming(false);
          setStreamingMessage('');
          setSessionError(error);
          setIsOpen(false);
          return;
        }
        throw new Error(error.code);
      }

      setIsThinking(false);

      // Parse JSON response
      const data = await response.json();

      const answer = data.answer || 'No response available.';
      const sources = data.sources || [];
      const confidence = data.confidence || 0;

      // Simulate streaming for smooth display
      let currentText = '';
      const chars = answer.split('');

      for (let i = 0; i < chars.length; i++) {
        await new Promise(resolve => setTimeout(resolve, 10));
        currentText += chars[i];
        setStreamingMessage(currentText);
      }

      // final message with sources
      setMessages([...newMessages, {
        role: 'assistant',
        content: answer,
        sources: sources,
        confidence: confidence
      }]);
      setStreamingMessage('');

    } catch (error) {
      setIsThinking(false);
      logger.error('Streaming error:', error)
      setMessages([...newMessages, {
        role: 'assistant',
        content: 'Session expired or invalid. Please close and try again.',
        isError: true
      }]);
    } finally {
      setIsStreaming(false);
      setIsThinking(false);
      setStreamingMessage('');
    }
  };
  // before streaming message section

  const handleSend = () => {
    sendMessageWithStreaming()
  };

  const handleClose = () => {
    setShowCloseDialog(true);
  };


  const confirmClose = async () => {
    // Stop streaming if active
    if (isStreaming && abortControllerRef.current) {
      abortControllerRef.current.abort();
    }

    // Call backend to close/terminate session
    if (sessionId) {
      try {
        const response = await api.deleteSession(sessionId);
        if (response.ok) {
          logger.info('Session closed on backend')
        } else {
          logger.error('Failed to close session:', response.status)
        }
      } catch (error) {
        logger.error('Error closing session:', error)
      }
    }

    setMessages([{ role: 'assistant', content: 'Hi! How can I help you today?' }]);
    setInputValue('');
    setStreamingMessage('');
    setFeedbackMap({});
    setExpandedFeedback(null);
    setFeedbackComment('');
    setCharCount(0);
    setIsThinking(false);
    setIsStreaming(false);
    setIsOpen(false);
    setShowCloseDialog(false);
    setHasUserSentMessage(false);
    setCurrentSessionMessageCount(1);

    // Notify parent
    if (window.parent !== window) {
      window.parent.postMessage({
        type: 'CHAT_CLOSED',
        sessionId: sessionId
      }, '*');
    }

    setSessionId(null);
    setChatUrl(null);
    logger.info('Session ended, conversation cleared')
  };

  const cancelClose = () => {
    setShowCloseDialog(false);
  };

  const truncate = (str, max = 20) =>
    str.length > max ? str.substring(0, max) + "…" : str;

  const handleThumbsUp = async (messageIndex) => {
    try {
      const response = await api.submitFeedback({
        session_id: sessionId,
        message_index: messageIndex,
        rating: 'positive',
        comment: null,
        message_content: messages[messageIndex].content
      }, sessionId);

      if (response.status === 401 || response.status === 403 || response.status === 404) {
        setSessionError('Session expired or invalid. Please close and try again.');
        setIsOpen(false);
        return;
      }

      if (!response.ok) {
        throw new Error('Failed');
      }

      setFeedbackMap(prev => ({
        ...prev,
        [messageIndex]: { type: 'up', disabled: true, showConfirm: true }
      }));

      setTimeout(() => {
        setFeedbackMap(prev => ({
          ...prev,
          [messageIndex]: { ...prev[messageIndex], showConfirm: false }
        }));
      }, FEEDBACK_CONFIRM_MS);

    } catch (error) {
      logger.error('Streaming error:', error)
    }
  };

  const handleThumbsDown = (messageIndex) => {
    setExpandedFeedback(messageIndex);
    setFeedbackMap(prev => ({
      ...prev,
      [messageIndex]: { type: 'down', disabled: true }
    }));
  };

  const handleCancelFeedback = (messageIndex) => {
    setExpandedFeedback(null);
    setFeedbackComment('');
    setFeedbackMap(prev => {
      const newMap = { ...prev };
      delete newMap[messageIndex];
      return newMap;
    });
  };

  const handleSubmitFeedback = async (messageIndex) => {
    try {
      const response = await api.submitFeedback({
        session_id: sessionId,
        message_index: messageIndex,
        rating: 'negative',
        comment: feedbackComment,
        message_content: messages[messageIndex].content
      }, sessionId);

      if (response.status === 401 || response.status === 403 || response.status === 404) {
        setSessionError('Session expired or invalid. Please close and try again.');
        setIsOpen(false);
        return;
      }

      if (!response.ok) {
        throw new Error('Failed to submit feedback');
      }

      setFeedbackMap(prev => ({
        ...prev,
        [messageIndex]: { type: 'down', disabled: true, showConfirm: true }
      }));

      setExpandedFeedback(null);
      setFeedbackComment('');

      setTimeout(() => {
        setFeedbackMap(prev => ({
          ...prev,
          [messageIndex]: { ...prev[messageIndex], showConfirm: false }
        }));
      }, 3000);
    } catch (error) {
      // console.error('Feedback submission error:', error);
      logger.error('Feedback submission error:', error)
    }
  };

  const getPlaceholder = () => {
    return messages.length > 1 ? "Ask a follow-up question..." : "Type your question...";
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Escape') {
      handleClose();
      return;
    }

    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      if (inputValue.trim().length >= MIN_INPUT_LENGTH && !isStreaming) {
        handleSend();
      }
    }
  };

  const handleInputChange = (e) => {
    const text = e.target.value.slice(0, MAX_CHARS);
    setInputValue(text);
    setCharCount(text.length);

    e.target.style.height = 'auto';
    const scrollHeight = e.target.scrollHeight;
    const maxHeight = 120; // 5 rows * 24px
    e.target.style.height = Math.min(scrollHeight, maxHeight) + 'px';
  };

  const toggleSources = (messageIndex) => {
    setExpandedSources(prev => ({
      ...prev,
      [messageIndex]: !prev[messageIndex]
    }));
  };

  const isValidSession = chatSessionId &&
    chatSessionId !== null &&
    chatSessionId !== 'null' &&
    typeof chatSessionId === 'string' &&
    chatSessionId.trim().length > 0;
  return (
    <div className="chat-widget" style={{ fontFamily: fontFamily }} >
      {!isLoading && isOpen && isValidSession ? (

        <>
          {/* Minimized floating button */}
          {isMinimized ? (
            <button
              className="chat-fab"
              onClick={() => setIsMinimized(false)}
              style={{ backgroundColor: primaryColor }}
              aria-label="Open chat"
            >
              Ask AI
            </button>
          ) : (

            <div className="chat-window" style={{ fontFamily: fontFamily }}>
              <div className="chat-header" style={{ backgroundColor: headerColor }}>
                <div className="chat-header-content">
                  <Tooltip
                    text={assistantTitle || 'Ask AI Assistant'}
                    backgroundColor={primaryColor}
                    position="bottom"
                  >
                    <h3>
                      {truncate(assistantTitle || 'Ask AI Assistant', TRUNCATE_TITLE)}
                    </h3>
                  </Tooltip>
                </div>
                <div className='widget-action-btn'>

                  {showMinimize && (
                    <button
                      className="chat-minimize-button"
                      onClick={() => setIsMinimized(!isMinimized)}
                      aria-label={isMinimized ? "Expand chat" : "Minimize chat"}
                    >
                      <svg width="24" height="24" viewBox="0 0 24 24">
                        <line x1="5" y1="12" x2="19" y2="12" stroke="currentColor" strokeWidth="2" />
                      </svg>
                    </button>
                  )}


                  <button
                    className="chat-close-button"
                    onClick={handleClose}
                    aria-label="Close chat"
                  >
                    ✕
                  </button>
                </div>
              </div>

              <div className="chat-messages" style={{ fontFamily: fontFamily }}>

                {messages.map((msg, i) => (
                  <div
                    key={i}
                    className={`message ${msg.role === 'user' ? 'message-user' : 'message-assistant'}`}
                  >
                    {msg.role === 'assistant' && (
                      <div className="message-avatar" style={{ backgroundColor: primaryColor }}>
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                          <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 3c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3zm0 14.2c-2.5 0-4.71-1.28-6-3.22.03-1.99 4-3.08 6-3.08 1.99 0 5.97 1.09 6 3.08-1.29 1.94-3.5 3.22-6 3.22z" />
                        </svg>
                      </div>
                    )}
                    <div className="message-content">
                      <div className="message-content">
                        <div className="message-bubble">

                          <ReactMarkdown
                            remarkPlugins={[remarkGfm]} rehypePlugins={[rehypeSanitize]}
                            components={{
                              p: ({ node, ...props }) => <p {...props} />,
                              code: ({ node, inline, ...props }) =>
                                inline ?
                                  <code style={{ background: 'rgba(0,0,0,0.1)', padding: '2px 6px', borderRadius: '4px' }} {...props} /> :
                                  <code style={{ display: 'block', background: 'rgba(0,0,0,0.1)', padding: '12px', borderRadius: '8px', overflowX: 'auto' }} {...props} />
                            }}
                          >
                            {msg.content}
                          </ReactMarkdown>
                        </div>
                        {/* Sources section */}

                        {msg.sources && msg.sources.length > 0 && (
                          <div className="sources-section">
                            <button
                              className="sources-toggle" style={{ border: `1px solid ${primaryColor}` }}
                              onClick={() => toggleSources(i)}
                            >
                              <span className="toggle-icon">{expandedSources[i] ? '▼' : '▶'}</span>
                              <span>Sources ({Math.min([...new Set(msg.sources.map(s => s.source))].length, 3)})</span>
                            </button>

                            {expandedSources[i] && (
                              <div className="sources-list">
                                {[...new Map(msg.sources.map(s => [s.source, s])).values()].slice(0, 3).map((source, idx) => {
                                  // query parameters
                                  const params = new URLSearchParams();
                                  params.append('session', sessionId);

                                  if (source.page_number) {
                                    params.append('page', source.page_number);
                                  }

                                  if (source.excerpt) {
                                    params.append('excerpt', source.excerpt);
                                  }

                                  const s3Key = source.s3_key || source.source;

                                  //view endpoint
                                  const viewUrl = getViewUrl(s3Key, params);
                                  return (

                                    <Tooltip
                                      text={source.source}
                                      backgroundColor={primaryColor}
                                      position="top"
                                    >
                                      <a
                                        key={idx}
                                        href={viewUrl}
                                        className="source-item"
                                        style={{
                                          border: `1px solid ${primaryColor}`
                                        }}
                                        target="_blank"
                                        rel="noopener noreferrer"
                                      >
                                        <span className="source-icon">📄</span>
                                        <span className="source-name">{source.source}</span>
                                        {source.page_number && (
                                          <>
                                            <span className="source-separator">•</span>
                                            <span className="source-page">Page {source.page_number}</span>
                                          </>
                                        )}
                                        <span className="source-arrow">→</span>
                                      </a>
                                    </Tooltip>
                                  );
                                })}
                              </div>
                            )}
                          </div>
                        )}

                        {msg.role === 'assistant' && i > 0 && (
                          feedbackMap[i] || // Always show if has feedback
                          (hasUserSentMessage ? i >= currentSessionMessageCount : i === messages.length - 1)
                        ) && (
                            <div className="feedback-section">
                              <div className="feedback-buttons">
                                <Tooltip text="Helpful" backgroundColor={primaryColor}>
                                  <button
                                    className={`feedback-btn ${feedbackMap[i]?.type === 'up' ? 'active-up' : ''}`}
                                    onClick={() => handleThumbsUp(i)}
                                    disabled={feedbackMap[i]?.disabled}
                                    style={{ border: `1px solid ${primaryColor}` }}
                                  >
                                    👍
                                  </button>
                                </Tooltip>

                                <Tooltip text="Not helpful" backgroundColor={primaryColor}>
                                  <button
                                    className={`feedback-btn ${feedbackMap[i]?.type === 'down' ? 'active-down' : ''}`}
                                    onClick={() => handleThumbsDown(i)}
                                    disabled={feedbackMap[i]?.disabled}
                                    style={{ border: `1px solid ${primaryColor}` }}
                                  >
                                    👎
                                  </button>
                                </Tooltip>
                              </div>

                              {/* Confirmation message */}
                              {feedbackMap[i]?.showConfirm && (
                                <span className="feedback-confirm">
                                  {feedbackMap[i]?.type === 'up' ? 'Thank you for your feedback!' : 'Feedback submitted'}
                                </span>
                              )}

                              {/* Comment box for thumbs down */}
                              {expandedFeedback === i && (
                                <div className="feedback-comment-box">
                                  <textarea
                                    placeholder="What went wrong? (500 characters max)"
                                    value={feedbackComment}
                                    onChange={(e) => setFeedbackComment(e.target.value.slice(0, MAX_FEEDBACK_CHARS))}
                                    maxLength={MAX_FEEDBACK_CHARS}
                                    rows="3"
                                  />
                                  <div className="feedback-actions">
                                    <button className="cancel-btn" onClick={() => handleCancelFeedback(i)}>
                                      Cancel
                                    </button>
                                    <button
                                      className="submit-btn"
                                      disabled={!feedbackComment || feedbackComment.trim().length < 3}
                                      onClick={() => handleSubmitFeedback(i)}
                                    >
                                      Submit {feedbackComment.trim().length < 3 && `(${feedbackComment.trim().length}/3)`}
                                    </button>
                                  </div>
                                </div>
                              )}
                            </div>
                          )}
                      </div>
                    </div>
                  </div>
                ))}

                {isStreaming && streamingMessage && (
                  <div className="message message-assistant">
                    <div className="message-avatar" style={{ backgroundColor: primaryColor }} >
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 3c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3zm0 14.2c-2.5 0-4.71-1.28-6-3.22.03-1.99 4-3.08 6-3.08 1.99 0 5.97 1.09 6 3.08-1.29 1.94-3.5 3.22-6 3.22z" />
                      </svg>
                    </div>
                    <div className="message-content">
                      <div className="message-bubble streaming">
                        <ReactMarkdown
                          remarkPlugins={[remarkGfm]} rehypePlugins={[rehypeSanitize]}
                          components={{
                            p: ({ node, ...props }) => <p  {...props} />,
                            code: ({ node, inline, ...props }) =>
                              inline ?
                                <code style={{ background: 'rgba(0,0,0,0.1)', padding: '2px 6px', borderRadius: '4px' }} {...props} /> :
                                <code style={{ display: 'block', background: 'rgba(0,0,0,0.1)', padding: '12px', borderRadius: '8px', overflowX: 'auto' }} {...props} />
                          }}
                        >
                          {streamingMessage}
                        </ReactMarkdown>
                      </div>
                    </div>
                  </div>
                )}

                {isStreaming && !streamingMessage && (
                  <div className="message message-assistant">
                    <div className="message-avatar" style={{ backgroundColor: primaryColor }}>
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 3c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3zm0 14.2c-2.5 0-4.71-1.28-6-3.22.03-1.99 4-3.08 6-3.08 1.99 0 5.97 1.09 6 3.08-1.29 1.94-3.5 3.22-6 3.22z" />
                      </svg>
                    </div>
                    <div className="message-content">
                      <div className="message-bubble typing-indicator">
                        <span style={{ backgroundColor: primaryColor }} ></span>
                        <span style={{ backgroundColor: primaryColor }} ></span>
                        <span style={{ backgroundColor: primaryColor }} ></span>
                      </div>
                    </div>
                  </div>
                )}

                <div ref={messagesEndRef} />
              </div>

              <div className="chat-input-container" style={{ fontFamily: fontFamily }}>
                <div className="chat-input">
                  {/* Left side icons */}
                  <textarea
                    ref={inputRef}
                    placeholder={getPlaceholder()}
                    value={inputValue}
                    onChange={handleInputChange}
                    onKeyDown={handleKeyDown}
                    disabled={isStreaming}
                    rows={1}
                    maxLength={MAX_CHARS}

                    style={{
                      resize: 'none',
                      overflow: 'auto',
                      overflowX: 'hidden',
                      minHeight: `${TEXTAREA_MIN_HEIGHT}px`,
                      maxHeight: `${TEXTAREA_MAX_HEIGHT}px`,
                      fontFamily: fontFamily
                    }}

                  />
                  <button
                    onClick={handleSend}
                    disabled={inputValue.trim().length < 3 || isStreaming}
                    className={`send-button ${isStreaming ? 'stop-button' : ''}`}
                    aria-label={isStreaming ? "Stop" : "Send message"} style={{ backgroundColor: primaryColor }}
                  >
                    {isStreaming ? (
                      <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                        <rect x="6" y="6" width="12" height="12" rx="2" />
                      </svg>
                    ) : (
                      <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M12 2L4 10h5v10h6V10h5L12 2z" />
                      </svg>
                    )}
                  </button>
                </div>


                <div className="chat-footer" style={{ fontFamily: fontFamily }}>

                  <span className="ai-disclaimer">
                    Usage subject to{' '}
                    <a
                      href="/eula.html"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="eula-link"
                    >
                      EULA
                    </a>
                  </span>
                </div>
                <ConfirmDialog
                  isOpen={showCloseDialog}
                  title="End chat ?"
                  message="When you close this chat, the next session will start as a new conversation. Previous messages won't be shown."
                  primaryButtonText="Close chat"
                  secondaryButtonText="Cancel"
                  primaryColor={primaryColor}
                  onConfirm={confirmClose}
                  onCancel={cancelClose}
                />
              </div>
            </div>
          )}


        </>

      ) : !isLoading && sessionError ? (
        <div className="chat-window" style={{ fontFamily: fontFamily }}>
          <div className="chat-header" style={{ backgroundColor: headerColor }}>
            <div className="chat-header-content">
              <Tooltip
                text={assistantTitle || 'Ask AI Assistant'}
                backgroundColor={primaryColor}
                position="bottom"
              >
                {/* style={{ color: primaryColor }} */}
                <h3 >
                  {truncate(assistantTitle || 'Ask AI Assistant', 30)}
                </h3>
              </Tooltip>
            </div>
            <button
              className="chat-close-button"
              onClick={handleCloseError}
              aria-label="Close chat"
            >
              ✕
            </button>
          </div>

          <div className="chat-messages" style={{ fontFamily: fontFamily }}>
            <div className="session-error" >
              <p>{sessionError?.message || 'Session expired. Please close and try again.'}</p>
              <button className="close-btn" onClick={handleCloseError} style={{ backgroundColor: primaryColor }}>
                Close
              </button>
            </div>
          </div>
        </div>
      ) : null
      }
    </div>

  );
}